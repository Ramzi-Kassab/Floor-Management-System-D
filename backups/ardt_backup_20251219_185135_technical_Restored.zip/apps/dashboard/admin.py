from django.contrib import admin

# Dashboard has no models
