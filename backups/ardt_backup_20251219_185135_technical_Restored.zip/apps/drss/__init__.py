default_app_config = "apps.drss.apps.DRSSConfig"
