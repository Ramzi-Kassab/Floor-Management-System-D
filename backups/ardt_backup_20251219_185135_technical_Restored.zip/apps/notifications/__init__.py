default_app_config = "apps.notifications.apps.NotificationsConfig"
