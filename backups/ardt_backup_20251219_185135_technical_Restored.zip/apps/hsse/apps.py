from django.apps import AppConfig


class HsseConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.hsse"
    verbose_name = "HSSE"
