default_app_config = "apps.supplychain.apps.SupplychainConfig"
