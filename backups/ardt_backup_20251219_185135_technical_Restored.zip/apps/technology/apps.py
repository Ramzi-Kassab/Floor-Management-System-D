from django.apps import AppConfig


class TechnologyConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.technology"
    verbose_name = "Technology"
