default_app_config = "apps.technology.apps.TechnologyConfig"
