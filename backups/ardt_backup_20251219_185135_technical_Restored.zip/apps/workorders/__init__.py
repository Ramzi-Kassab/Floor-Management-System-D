default_app_config = "apps.workorders.apps.WorkOrdersConfig"
