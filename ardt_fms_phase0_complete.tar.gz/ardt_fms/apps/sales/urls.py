from django.urls import path

app_name = 'sales'

urlpatterns = []
