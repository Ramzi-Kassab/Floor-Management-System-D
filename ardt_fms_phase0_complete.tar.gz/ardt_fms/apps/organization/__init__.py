# Organization App
default_app_config = 'apps.organization.apps.OrganizationConfig'
