from django.urls import path

app_name = 'organization'

urlpatterns = [
    # URLs will be added in Sprint 1
]
