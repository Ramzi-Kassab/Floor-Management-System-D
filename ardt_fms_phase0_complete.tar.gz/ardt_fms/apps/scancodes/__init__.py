default_app_config = 'apps.scancodes.apps.ScancodesConfig'
