from django.urls import path

app_name = 'supplychain'

urlpatterns = []
