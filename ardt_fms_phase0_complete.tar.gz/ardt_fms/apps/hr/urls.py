from django.urls import path

app_name = 'hr'

urlpatterns = []
