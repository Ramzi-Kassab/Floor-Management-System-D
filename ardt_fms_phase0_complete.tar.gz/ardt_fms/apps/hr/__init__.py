default_app_config = 'apps.hr.apps.HrConfig'
