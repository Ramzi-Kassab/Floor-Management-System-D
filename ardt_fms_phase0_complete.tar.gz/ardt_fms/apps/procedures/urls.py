from django.urls import path

app_name = 'procedures'

urlpatterns = [
    # URLs will be added in Sprint 7-8
]
