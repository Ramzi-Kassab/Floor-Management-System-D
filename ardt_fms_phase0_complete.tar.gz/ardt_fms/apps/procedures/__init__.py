# Procedures App
default_app_config = 'apps.procedures.apps.ProceduresConfig'
