from django.urls import path

app_name = 'execution'

urlpatterns = []
