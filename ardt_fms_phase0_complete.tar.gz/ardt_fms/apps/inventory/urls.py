from django.urls import path

app_name = 'inventory'

urlpatterns = []
