from django.urls import path

app_name = 'documents'

urlpatterns = []
