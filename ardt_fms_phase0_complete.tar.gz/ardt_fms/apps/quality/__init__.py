default_app_config = 'apps.quality.apps.QualityConfig'
