default_app_config = 'apps.hsse.apps.HsseConfig'
