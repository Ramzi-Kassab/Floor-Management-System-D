from django.urls import path

app_name = 'maintenance'

urlpatterns = []
