default_app_config = 'apps.maintenance.apps.MaintenanceConfig'
